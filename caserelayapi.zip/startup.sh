#!/bin/bash
cd "${BASH_SOURCE%/*}" || exit  # Ensure we're in the right directory
export ASPNETCORE_URLS="http://+:5000"
export ASPNETCORE_ENVIRONMENT="Production"
dotnet CaseRelayAPI.dll
